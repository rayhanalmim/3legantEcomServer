import express from "express";
import { ProductsController } from "./product.service";
const router = express.Router();

router.post("/create-product", ProductsController.createProducts);
router.get("/get-products", ProductsController.GetProducts);
router.get("/get-product/:id", ProductsController.GetSingleProducts);
router.put("/update-product/:id", ProductsController.UpdateProduct);
router.delete("/delete-product/:id", ProductsController.DeleteProducts);

export const ProductRoutes = router;